# =================================================================================
# Name: MONASSIS Template
# Author: Francois Jooste
# Date: 6 August 2013
# =================================================================================

# import random
# import math
# import numpy
# import sympy

#-------------------------------------------------------
# User-defined functions
#-------------------------------------------------------

# Function to generate a value with a certain number of significant figures with a non-zero terminal digit 
def sig_fig_num(low,up,sig_figs):
    if low == up:
        parts = ('{0:.'+str(sig_figs-1)+'e}').format(low).split('e')
    else:
        parts = ('{0:.'+str(sig_figs-1)+'e}').format(random.uniform(low,up)).split('e')
    if parts[0].rstrip('0') == parts[0]:
        part_1 = parts[0]
    else:
        part_1 = parts[0].rstrip('0') + str(1)
    part_2 = parts[1]
    sig_fig_num = float(part_1 + 'e' + part_2)
    return sig_fig_num

# Function to determine instructions for rounding to correct number of significant figures
def rounding_words(number):
    split_string = ''
    string = str(number).strip('-')
    split_string = string.split('.')
    if len(split_string) == 1:
        power_of_ten = 0
        if split_string[0] != '0':
            test_index = -1
            test_digit = split_string[0][test_index]
            while test_digit == '0':
                test_index -= 1
                test_digit = split_string[0][test_index]
                power_of_ten += 1
        if power_of_ten == 0:
            rounding_words = 'the nearest integer'
        else:
            rounding_words = 'the nearest ' + str(10**power_of_ten)
    elif split_string[1] == '':
        rounding_words = 'the nearest integer'
    elif len(split_string[1]) == 1:
        rounding_words = '1 decimal place after the decimal comma'
    elif len(split_string[1]) > 1:
        rounding_words = str(len(split_string[1])) + ' decimal places after the decimal comma'
    return rounding_words

# Function to construct Latex code for a truncated number with ellipses added. Used to represent an exact calculated number in XML
def trunc_num(number, places):
    split_string = str(number).split('.')
    if split_string[1] == '0':
        xml_string = split_string[0] + ',' + split_string[1]
    else:
        xml_string = split_string[0] + ',' + split_string[1][:places] + r' \ldots'
    return xml_string


#-------------------------------------------------------
# Properties of system components (Physics of system)
#-------------------------------------------------------
list_of_sources = [
    {
    'vehicle':'ambulance',
    'article_low':'an',
    'article_up':'An',
    'sound_device':'siren',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'police motorcycle',
    'article_low':'a',
    'article_up':'A',
    'sound_device':'siren',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'construction vehicle',
    'article_low':'a',
    'article_up':'A',
    'sound_device':'warning signal',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'police van',
    'article_low':'a',
    'article_up':'A',
    'sound_device':'siren',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'firetruck',
    'article_low':'a',
    'article_up':'A',
    'sound_device':'siren',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'garbage truck',
    'article_low':'a',
    'article_up':'A',
    'sound_device':'warning signal',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'mechanical street sweeper',
    'article_low':'a',
    'article_up':'A',
    'sound_device':'warning signal',
    'upper_v':80,
    'lower_v':40},]

# list_of_listener_1_places = [
#     'at a pedestrian crossing',
#     'at a hot dog stand',
#     'at the side of the road',
#     'at an ice cream kiosk',
#     'at a bus stop shelter']

list_of_listeners = [
    {
    'vehicle':'car',
    'article':'a',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'bus',
    'article':'a',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'delivery van',
    'article':'a',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'pickup truck',
    'article':'a',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'taxi',
    'article':'a',
    'upper_v':80,
    'lower_v':40},
    {
    'vehicle':'minibus',
    'article':'a',
    'upper_v':80,
    'lower_v':40}]

people_list = [(names.generate_male()),(names.generate_female())]

#people_list = ['A','B']

random.shuffle(people_list)

person_1 = people_list[0]
person_2 = people_list[1]

source_choice = random.choice(list_of_sources)
listener_1_choice = random.choice(list_of_listeners)
listener_2_choice = random.choice(list_of_listeners)

sig_figs = random.randint(3,4)

v_value = sig_fig_num(335,350,sig_figs) #m/s
v_L1_value_km_per_h = sig_fig_num(listener_1_choice['lower_v'],listener_1_choice['upper_v'],sig_figs)
v_L1_value = v_L1_value_km_per_h/3.6 #m/s

test_value = 0
while test_value < 5:
    v_L2_value_km_per_h = sig_fig_num(listener_2_choice['lower_v'],listener_2_choice['upper_v'],sig_figs) #km/h
    test_value = abs(v_L1_value_km_per_h - v_L2_value_km_per_h)

v_L2_value = v_L2_value_km_per_h/3.6 #m/s

test_value = 0
while test_value < 10:
    v_S_value_km_per_h = sig_fig_num(source_choice['lower_v'],source_choice['upper_v'],sig_figs) #km/hr
    test_value = abs(v_L1_value_km_per_h - v_S_value_km_per_h)

v_S_value = v_S_value_km_per_h/3.6 #m/s

f_S_value = sig_fig_num(200,800,sig_figs) #Hz

#Define symbolic variables for use with sympy
v = sympy.Symbol('v')
v_L1 = sympy.Symbol('v_L1')
v_L2 = sympy.Symbol('v_L2')
v_S = sympy.Symbol('v_S')
f_S = sympy.Symbol('f_S')
f_L1 = sympy.Symbol('f_L1')
f_L2 = sympy.Symbol('f_L2')

#Equation set - Doppler
E_1 = f_S*(v - v_L1)/(v - v_S) -f_L1
E_2 = f_S*(v - v_L2)/(v - v_S) -f_L2

# if v_L1_value < v_S_value:
#     E_1 = f_S*(v + v_L1)/(v - v_S) -f_L1
# else:
#     E_1 = f_S*(v - v_L1)/(v + v_S) -f_L1

# if v_L2_value < v_S_value:
#     E_2 = f_S*(v + v_L2)/(v - v_S) -f_L2
# else:
#     E_2 = f_S*(v - v_L2)/(v + v_S) -f_L2


#Solving for 5 unknowns and storing results in dictionary 
# solved_v = sympy.solve([E_1], [v])
# solved_v_L = sympy.solve([E_1], [v_L])
# solved_v_S = sympy.solve([E_1], [v_S])
# solved_f_S = sympy.solve([E_1], [f_S])
solved_f_L1 = sympy.solve([E_1], [f_L1])
solved_f_L2 = sympy.solve([E_2], [f_L2])

f_L1_value = solved_f_L1[f_L1].subs([(v,v_value),(v_L1,v_L1_value),(v_S,v_S_value),(f_S,f_S_value)])
f_L2_value = solved_f_L2[f_L2].subs([(v,v_value),(v_L2,v_L2_value),(v_S,v_S_value),(f_S,f_S_value)])

#-------------------------------------------------------
# Determine XML parameters
#-------------------------------------------------------

#Problem statement
xml_source = source_choice
xml_listener_1 = listener_1_choice
xml_listener_2 = listener_2_choice

xml_person_1 = person_1
xml_person_2 = person_2

xml_v   = ('{0:.' + str(sig_figs) +'g}').format(float(v_value))
xml_v_L1_km_per_h = ('{0:.' + str(sig_figs) +'g}').format(float(v_L1_value_km_per_h))
xml_v_L1 = ('{0:.' + str(sig_figs) +'g}').format(float(v_L1_value))
xml_v_L2_km_per_h = ('{0:.' + str(sig_figs) +'g}').format(float(v_L2_value_km_per_h))
xml_v_L2 = ('{0:.' + str(sig_figs) +'g}').format(float(v_L2_value))
xml_v_S_km_per_h = ('{0:.' + str(sig_figs) +'g}').format(float(v_S_value_km_per_h))
xml_v_S = ('{0:.' + str(sig_figs) +'g}').format(float(v_S_value))
xml_f_S = ('{0:.' + str(sig_figs) +'g}').format(float(f_S_value))
xml_f_L1 = ('{0:.' + str(sig_figs) +'g}').format(float(f_L1_value))
xml_f_L2 = ('{0:.' + str(sig_figs) +'g}').format(float(f_L2_value))

# Questions
if len(xml_f_L1) >= len(xml_f_L2):
    xml_decimal_place_question_1_and_2 = rounding_words(xml_f_L1)
else:
    xml_decimal_place_question_1_and_2 = rounding_words(xml_f_L2)

xml_answer_1_numeric_correct = xml_f_L1
xml_answer_2_numeric_correct = xml_f_L2

xml_answer_3_options = [person_1,person_2]
if f_L1_value > f_L2_value:
    xml_answer_3_choice_correct = 0
else:
    xml_answer_3_choice_correct = 1


# # Question 1 Solution
xml_v_L1_truncated = trunc_num(float(v_L1_value),3)
xml_v_L2_truncated = trunc_num(float(v_L2_value),3)
xml_v_S_truncated = trunc_num(float(v_S_value),3)
xml_f_L1_truncated = trunc_num(float(f_L1_value),5)
xml_f_L2_truncated = trunc_num(float(f_L2_value),5)

#-------------------------------------------------------
# Determine Tikz parameters
#-------------------------------------------------------

tikz_L1_label = person_1 + ' in ' + listener_1_choice['article'] + ' ' + listener_1_choice['vehicle'] + ' moving at ' + xml_v_L1_km_per_h.replace('.',',') + r' km/hr'

tikz_L2_label = person_2 + ' in ' + listener_2_choice['article'] + ' ' + listener_2_choice['vehicle'] + ' moving at ' + xml_v_L2_km_per_h.replace('.',',') + r' km/hr'

tikz_S_label = source_choice['article_up'] + ' ' + source_choice['vehicle'] + ' with a ' + source_choice['sound_device'] + ' moving at ' + xml_v_S_km_per_h.replace('.',',') + r' km/hr'

if min([v_L1_value,v_L2_value,v_S_value]) == v_L1_value:
    tikz_v_L1_arrow_length = 1
    tikz_v_L2_arrow_length = round(v_L2_value/v_L1_value,2)
    tikz_v_S_arrow_length = round(v_S_value/v_L1_value,2)
elif min([v_L1_value,v_L2_value,v_S_value]) == v_L2_value:
    tikz_v_L1_arrow_length = round(v_L1_value/v_L2_value,2)
    tikz_v_L2_arrow_length = 1
    tikz_v_S_arrow_length = round(v_S_value/v_L2_value,2)
elif min([v_L1_value,v_L2_value,v_S_value]) == v_S_value:
    tikz_v_L1_arrow_length = round(v_L1_value/v_S_value,2)
    tikz_v_L2_arrow_length = round(v_L2_value/v_S_value,2)
    tikz_v_S_arrow_length = 1

